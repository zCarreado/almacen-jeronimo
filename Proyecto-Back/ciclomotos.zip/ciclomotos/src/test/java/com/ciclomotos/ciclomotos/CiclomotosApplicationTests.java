package com.ciclomotos.ciclomotos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CiclomotosApplicationTests {

	@Test
	void contextLoads() {
	}

}
